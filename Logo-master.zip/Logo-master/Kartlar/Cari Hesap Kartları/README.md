**ACTIVE**|**Ad**
-----|-----
1|Alıcı
2|Satıcı
3|Alıcı+Satıcı
