|          |     |                                     | 
|----------|-----|-------------------------------------| 
| CURRSTAT | doc | AÇIKLAMA                            | 
| 1        | 1   | Müşteriye iade                      | 
| 2        | 1   | Portföyden tahsil                   | 
| 3        | 1   | Bankada tahsil                      | 
| 4        | 1   | Portföyde karşılıksız               | 
| 5        | 1   | Bankada karşılıksız                 | 
| 6        | 1   | Müşteriden portföye iade            | 
| 7        | 1   | Bankadan portföye iade              | 
| 8        | 1   | Müşteriden karşılıksız iade         | 
| 9        | 1   | Cirodan tahsil, A:Tahsil edilemiyor | 
|          |     |                                     | 
| 1        | 2   | Müşteriye iade                      | 
| 2        | 2   | Portföy-den tahsil                  | 
| 3        | 2   | Bankada tahsil                      | 
| 4        | 2   | Portföyde protestolu                | 
| 5        | 2   | Bankada protestolu                  | 
| 6        | 2   | Müşteriden portföye iade            | 
| 7        | 2   | Bankadan portföye iade              | 
| 8        | 2   | Müşteriden protestolu iade          | 
| 9        | 2   | Cirodan tahsil, A:Tahsil edilemiyor | 
