-- LOGO Kullanıcısının şifresini sıfırlama
-- Update sonrasında şifre "LOGO" olacaktır


UPDATE L_CAPIUSER SET KEY_='euJJEHdEK+Cia8C1v5Q8JQ==' WHERE NR=1